# VPS Gurad — Multi-Attack Detection & Auto-Block

A defensive VPS monitoring tool: a central web dashboard, one lightweight
agent per protected VPS, automatic host-firewall blocking, and an optional
kernel-level rate-limiting layer underneath it.

## Important — read this first

No host-level program can truthfully provide "100% protection against all
attacks." A large enough volumetric flood can saturate your upstream
network bandwidth before any of that traffic even reaches this tool —
by the time a packet arrives at your VPS for inspection, the pipe is
already full. **Put your VPS provider's upstream DDoS mitigation in front
of this tool as the first layer.** This tool is the second layer: it
detects and blocks attack patterns that make it past your upstream, at
the host level, in real time.

This tool focuses on connection/request-rate abuse and suspicious source
IPs. It intentionally does not inspect packet payloads, passwords, or
private content beyond the minimum needed to spot a login-brute-force
attempt (source IP and pass/fail, never the password itself).

## What it detects and blocks

| Detector | Layer | What it catches |
|---|---|---|
| Connection flood | Host, TCP | High/rapidly-rising raw connection count from one source |
| SYN flood | Host, TCP | Half-open (SYN-RECV) connection bursts — classic resource-exhaustion |
| Port scan | Host, TCP | Many distinct destination ports touched fast by one source |
| SSH / login brute force | Host, auth log | Repeated failed logins from one source in a rolling window |
| UDP flood | Host, UDP | High UDP packet/socket volume from one source (a signal, not proof — UDP is connectionless) |
| HTTP flood (Layer 7) | Application, nginx/Apache log | High real-request rate from one source — catches floods that hold few raw connections open but fire requests fast, which the TCP-level detectors structurally cannot see |
| Kernel-level SYN/UDP rate limit | Kernel, iptables | Optional second layer (`kernel-hardening.sh`) that drops excess packets in-kernel, before they reach the agent at all — faster than any userspace polling loop |

Each protected VPS runs its own agent and blocks locally via that VPS's
own firewall. All agents report to one central dashboard for visibility
across your whole fleet.

## Install (recommended: one command)

Requires Node.js 20+ and a Linux VPS with systemd (Ubuntu, Debian, and
most others). This single command copies the project to `/opt/vps-guard`,
installs dependencies, runs first-time setup, creates an unprivileged
dashboard user, installs kernel-level rate limiting, and starts both
services under systemd — so there's no separate manual systemd setup
afterward, and no token to copy-paste between `config.json` and a service
file by hand (that copy-paste step is what used to cause "login doesn't
work" — see Troubleshooting below).

```bash
sudo ./install.sh
```

You'll be asked for an admin username/password and how many VPS agents
will report to this dashboard (`1` for a single-server setup). Everything
else is automatic.

Re-running `sudo ./install.sh` at any time is safe — it's idempotent and
will not duplicate services, disturb the running system user, or touch
your existing admin credentials. Other useful modes:

```bash
sudo ./install.sh --reset-credentials   # forgot your password — sets a new one and
                                         # correctly re-threads the new token everywhere
sudo ./install.sh --agent-only          # run on an ADDITIONAL VPS to join an existing
                                         # dashboard (prompts for its URL/token/label)
sudo ./install.sh --dashboard-only      # central dashboard box with no local agent
sudo ./install.sh --uninstall           # stop everything and optionally remove all files
```

For a multi-VPS fleet, `install.sh` prints ready-to-run `--agent-only`
commands for each additional VPS at the end — copy each block to its
matching server and run it there.

Open the dashboard on the box it runs on:

`http://127.0.0.1:8787`

For remote administration, use an SSH tunnel or a properly authenticated
HTTPS reverse proxy. **Do not expose the raw dashboard to the public
internet.**

## Install (manual / advanced)

If you'd rather not use `install.sh` — no systemd, a non-standard layout,
or you just want full manual control:

```bash
npm install
node setup.js
npm start
```

`setup.js` asks the same questions `install.sh` does and creates
`config.json` (and `agents.json`, if multi-agent) with mode `600`
automatically. In this path, threading the token into a systemd unit or
into another VPS's environment is a manual step — see `systemd/README.md`
if you're setting that up by hand, and double-check the token in the unit
file / environment variable matches `internalToken` in `config.json`
exactly if login/agent-reporting doesn't work afterward.

Start the agent directly:

```bash
sudo node agent.js          # Linux
```

```powershell
# Windows — run PowerShell as Administrator
node agent.js
```

Multi-VPS, manual: on each additional VPS, point it at the central
dashboard with its own token/label from `agents.json`:

```bash
VPS_GURAD_SERVER=https://your-dashboard-host \
VPS_GURAD_AGENT_TOKEN=<one token from agents.json> \
VPS_GURAD_AGENT_ID=vps-2 \
sudo node agent.js
```

## Troubleshooting: "Invalid username or password"

Two different things can cause this, and they need different fixes:

**You typed it correctly and it still fails.** The most common cause is a
trailing newline picked up from copy-pasting the password (from a text
file, terminal, or password manager) or stray spaces around the username
from autofill. As of this version, the dashboard tolerates both
automatically — a trailing newline in the password and surrounding
whitespace in the username are stripped before checking, so this
shouldn't happen anymore. If it still does, check you're not accidentally
including a leading/trailing space *inside* the password field on paste
(genuinely part of the password isn't touched, only newline artifacts
are) — try typing it manually once to rule this out.

**You genuinely don't remember the password, or `config.json` is stale**
(e.g. `setup.js` or `install.sh` was run more than once and you're not
sure which credentials are live). Reset it — this generates a fresh
password and correctly updates every place the corresponding token is
used (the systemd unit, if installed via `install.sh`):

```bash
sudo ./install.sh --reset-credentials
```

If you set this up manually (not via `install.sh`) and only need to
change the password without touching tokens, re-run `node setup.js`
directly and restart `npm start` — but if you're running under systemd
with a manually-edited unit file, remember to update the token there too,
or use `install.sh` instead, which does this automatically.

## Start the agent under systemd manually

If you used `install.sh`, this is already done — skip this section.
Otherwise, or to understand what `install.sh` automates, see
`systemd/README.md`. Running both processes under systemd (rather than a
foreground terminal) is what makes the tool survive reboots and
auto-restart after a crash — i.e. actually run 24/7.

## Kernel-level rate limiting (recommended, Linux only)

A second, faster line of defense underneath the agent — drops excess SYN
and UDP packets per source IP in the kernel, before they ever reach
Node.js. The agent's detectors poll every 5 seconds; this acts in
microseconds.

```bash
sudo ./kernel-hardening.sh          # install (safe to re-run any time)
sudo ./kernel-hardening.sh --status # see rule hit counts
sudo ./kernel-hardening.sh --remove # fully uninstall
```

Read the comments at the top of the script before running it — it edits
your live firewall. In short: SSH gets its own separate, more generous
limit so a flood against any other port can never lock you out over SSH;
defaults are deliberately generous so a page going viral or an office NAT
sending many users doesn't get caught; everything lives in one dedicated,
fully removable chain and never touches your other iptables rules.

If installed under systemd (see above), this re-runs automatically on
every agent start/reboot — iptables rules normally don't survive a
reboot on their own, so without systemd you'd need to re-run this by hand
after any restart.

## What is protected

- Connection floods, SYN floods, port scans, SSH/login brute force, UDP
  floods, and HTTP (Layer 7) floods — see the detector table above
- Optional kernel-level SYN/UDP rate limiting, underneath the agent
- Temporary automatic source-IP blocking, per VPS, via that VPS's own
  firewall (Linux iptables dedicated chain / Windows Defender Firewall)
- Bounded in-memory tracking everywhere (capped maps/sets) — the tool
  itself cannot become a resource-exhaustion problem under real attack
  volume
- Central dashboard authentication, scrypt password hashing, timing-safe
  comparisons, per-agent tokens for multi-VPS setups
- HTTP security headers on the dashboard
- No raw packet payload logging, no password logging

## Production recommendations

- Use `sudo ./install.sh` rather than the manual path — it removes the
  token-copy-paste step that's the most common source of "agent doesn't
  report" / "login doesn't work" problems.
- Put upstream/provider DDoS mitigation in front of the VPS — this tool
  is the second layer, not a replacement for the first.
- Keep `config.json` and `agents.json` mode `600` (both `setup.js` and
  `install.sh` do this automatically).
- Keep the dashboard bound to localhost; use an SSH tunnel or an
  authenticated HTTPS reverse proxy for remote access.
- Give each VPS in a multi-agent fleet its own token from `agents.json` —
  never share one token across VPS instances.
- Tune the thresholds in `config.json` for your actual traffic (a busy
  public site's normal connection rate looks different from a quiet API
  box's) rather than relying on the defaults unmodified.
- Back up your firewall configuration before first deployment.
- Do not publish `config.json` or `agents.json`.

## Tests

`tests/` contains the automated checks written while building this —
detector scoring logic against synthetic attack scenarios, the IPv6
connection-parsing fix, server-side security logic (password hashing,
timing-safe comparisons, token lookup, the login-input-cleaning fix), the
HTTP-flood log tailer against realistic nginx/Apache log lines including
log rotation, and a regression test for `install.sh` itself (catches the
kind of silent, distro-specific shell-portability bug that's easy to miss
by eye — the exact one found and fixed while building this). Run the
Node-based checks with `node tests/<file>.mjs`; run the install.sh check
with `bash tests/test-install-sh.sh`. Each prints PASS/FAIL per check.
