import assert from "node:assert/strict";

function privateIP(ip) {
  if (ip === "127.0.0.1" || ip === "::1" || ip === "0.0.0.0" || ip === "::") return true;
  if (/^10\./.test(ip) || /^192\.168\./.test(ip)) return true;
  const m = ip.match(/^172\.(\d+)\./);
  return !!(m && +m[1] >= 16 && +m[1] <= 31);
}

function ipPortFromSs(line) {
  const parts = line.trim().split(/\s+/);
  for (let i = parts.length - 1; i >= 0; i--) {
    const x = parts[i];
    let m = x.match(/^\[([0-9a-fA-F:]+)\]:(\d+)$/);
    if (m) return { ip: m[1], port: +m[2] };
    m = x.match(/^(\d+\.\d+\.\d+\.\d+):(\d+)$/);
    if (m) return { ip: m[1], port: +m[2] };
    if (x === "*:*" || x === ":::*" || /^\*:/.test(x)) continue;
    const lastColon = x.lastIndexOf(":");
    if (lastColon > 0) {
      const addr = x.slice(0, lastColon);
      const portStr = x.slice(lastColon + 1);
      if (/^\d+$/.test(portStr) && (addr.match(/:/g) || []).length >= 2 && /^[0-9a-fA-F:]+$/.test(addr) && addr !== "*") {
        return { ip: addr, port: +portStr };
      }
    }
  }
  return null;
}

// privateIP
assert.equal(privateIP("127.0.0.1"), true);
assert.equal(privateIP("10.0.0.5"), true);
assert.equal(privateIP("192.168.1.1"), true);
assert.equal(privateIP("172.16.0.1"), true);
assert.equal(privateIP("172.31.255.255"), true);
assert.equal(privateIP("172.32.0.1"), false);
assert.equal(privateIP("172.15.0.1"), false);
assert.equal(privateIP("8.8.8.8"), false);
assert.equal(privateIP("::1"), true, "unbracketed ::1 (as now returned by fixed parser) correctly flagged private");
console.log("PASS: privateIP boundary checks");

// ipPortFromSs — the fixed version
assert.deepEqual(ipPortFromSs("ESTAB      0      0           10.0.0.5:22            203.0.113.7:51422"), { ip: "203.0.113.7", port: 51422 });
assert.deepEqual(ipPortFromSs("ESTAB      0      0     [::1]:22               [2001:db8::5]:443"), { ip: "2001:db8::5", port: 443 }, "bracketed IPv6 now parses correctly");
assert.deepEqual(ipPortFromSs("LISTEN     0      128               :::sunrpc :::*"), null, "wildcard IPv6 listen line ignored");
assert.deepEqual(ipPortFromSs("LISTEN     0      511               *:80                    *:*"), null);
assert.equal(ipPortFromSs(""), null);
assert.equal(ipPortFromSs("garbage line with no colons"), null);
// realistic full established-connection lines, both directions
assert.deepEqual(ipPortFromSs("ESTAB 0 0 [2603:1234::10]:443 [2001:db8::5]:51422"), { ip: "2001:db8::5", port: 51422 }, "remote (last) field extracted even when local is also IPv6");
console.log("PASS: ipPortFromSs, including previously-broken IPv6 cases");

// downstream effect: does the fixed ip flow correctly into privateIP for
// the loopback/private filtering that agent.js relies on?
const loopbackLine = "ESTAB 0 0 [::1]:22 [::1]:51422";
const parsed = ipPortFromSs(loopbackLine);
assert.equal(privateIP(parsed.ip), true, "loopback IPv6 connections still correctly filtered out end-to-end");
console.log("PASS: end-to-end IPv6 loopback filtering");

console.log("\nALL AGENT LOGIC TESTS PASSED (fixed version)");
