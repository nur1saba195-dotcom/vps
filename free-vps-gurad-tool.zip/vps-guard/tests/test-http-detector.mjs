import assert from "node:assert/strict";
import fs from "node:fs";

// --- Functions under test, matching what will go into agent.js ---

function extractIPFromLogLine(line) {
  const m = line.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|[0-9a-fA-F:]+)\s+\S+\s+\S+\s+\[/);
  return m ? m[1] : null;
}

function makeTailer(filePath) {
  let offset = 0;
  return function readNew() {
    let stat;
    try { stat = fs.statSync(filePath); } catch { return []; }
    if (stat.size < offset) offset = 0;
    if (stat.size === offset) return [];
    const fd = fs.openSync(filePath, "r");
    const len = Math.min(stat.size - offset, 2_000_000); // cap per-tick read to protect memory even if something writes an enormous burst
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, offset);
    fs.closeSync(fd);
    offset += len;
    return buf.toString("utf8").split("\n").filter(Boolean);
  };
}

// --- Tests ---

const testFile = "/tmp/test-http-access.log";
fs.writeFileSync(testFile, "");

const tail = makeTailer(testFile);
assert.deepEqual(tail(), [], "empty file returns no lines");

fs.appendFileSync(testFile,
  '203.0.113.7 - - [12/Aug/2026:10:15:03 +0000] "GET / HTTP/1.1" 200 396 "-" "Mozilla/5.0"\n' +
  '203.0.113.7 - - [12/Aug/2026:10:15:04 +0000] "GET /login HTTP/1.1" 200 512 "-" "Mozilla/5.0"\n'
);
const batch1 = tail();
assert.equal(batch1.length, 2, "reads exactly the newly appended lines");
const ips1 = batch1.map(extractIPFromLogLine);
assert.deepEqual(ips1, ["203.0.113.7", "203.0.113.7"], "extracts correct IP from both lines");
console.log("PASS: basic tail + IP extraction");

assert.deepEqual(tail(), [], "second call with no new writes returns nothing");
console.log("PASS: no duplicate reads");

// Simulate an HTTP flood: 500 rapid requests from one IP
const floodLines = [];
for (let i = 0; i < 500; i++) {
  floodLines.push(`198.51.100.9 - - [12/Aug/2026:10:15:10 +0000] "GET /?x=${i} HTTP/1.1" 200 100 "-" "Mozilla/5.0"`);
}
fs.appendFileSync(testFile, floodLines.join("\n") + "\n");
const batch2 = tail();
assert.equal(batch2.length, 500, "reads all 500 flood lines");
const floodIPs = batch2.map(extractIPFromLogLine).filter(Boolean);
assert.equal(floodIPs.length, 500);
assert.ok(floodIPs.every(ip => ip === "198.51.100.9"), "all flood lines correctly attributed to the flooding IP");
console.log("PASS: HTTP flood scenario — 500 requests correctly counted from one IP");

// Log rotation simulation
fs.writeFileSync(testFile, '10.99.99.1 - - [12/Aug/2026:10:20:00 +0000] "GET / HTTP/1.1" 200 200 "-" "curl/8"\n');
const afterRotation = tail();
assert.equal(afterRotation.length, 1, "correctly picks up from a rotated (truncated+rewritten) log file rather than erroring or going silent forever");
console.log("PASS: log rotation handled");

fs.unlinkSync(testFile);
console.log("\nALL HTTP DETECTOR TESTS PASSED");
