import assert from "node:assert/strict";

// Reimplementation of tick()'s scoring/decision core, extracted so it can be
// driven with synthetic snapshots without needing real ss/iptables/journalctl.
const cfg = {
  connectionThreshold: 120, synThreshold: 40, portScanThreshold: 15,
  authFailThreshold: 6, udpThreshold: 200, scoreThreshold: 60, blockSeconds: 900
};

function runDetectors(snap, failIPs, state) {
  const { prevConn, prevSyn, portsSeen, authFail, prevUdp } = state;
  const attackers = new Map();
  const now = Date.now();
  let totalConn = 0;

  function consider(ip, score, reason, connCount) {
    const existing = attackers.get(ip);
    if (!existing || score > existing.score) attackers.set(ip, { ip, score, reason, connections: connCount });
  }

  for (const [ip, count] of snap.tcpTotal) {
    totalConn += count;
    const old = prevConn.get(ip) ?? count;
    const delta = Math.max(0, count - old);
    prevConn.set(ip, count);
    const score = Math.min(100, Math.round((count / cfg.connectionThreshold) * 65 + (delta / 40) * 35));
    if (count >= cfg.connectionThreshold || score >= cfg.scoreThreshold) consider(ip, score, "connection_flood", count);
    else if (score >= 30) consider(ip, score, "connection_flood_watch", count);
  }

  for (const [ip, synCount] of snap.tcpSyn) {
    const old = prevSyn.get(ip) ?? synCount;
    const delta = Math.max(0, synCount - old);
    prevSyn.set(ip, synCount);
    const score = Math.min(100, Math.round((synCount / cfg.synThreshold) * 70 + (delta / 15) * 30));
    if (synCount >= cfg.synThreshold || score >= cfg.scoreThreshold) consider(ip, score, "syn_flood", snap.tcpTotal.get(ip) || synCount);
  }

  for (const [ip, set] of snap.scanPorts) {
    const prevSet = portsSeen.get(ip);
    const growth = prevSet ? Math.max(0, set.size - prevSet.size) : 0;
    portsSeen.set(ip, set);
    const score = Math.min(100, Math.round((set.size / cfg.portScanThreshold) * 60 + (growth / 8) * 40));
    if (set.size >= cfg.portScanThreshold || score >= cfg.scoreThreshold) consider(ip, score, "port_scan", snap.tcpTotal.get(ip) || set.size);
  }

  for (const ip of failIPs) {
    let arr = authFail.get(ip);
    if (!arr) { arr = []; authFail.set(ip, arr); }
    arr.push(now);
  }
  for (const [ip, arr] of authFail) {
    const score = Math.min(100, Math.round((arr.length / cfg.authFailThreshold) * 100));
    if (arr.length >= cfg.authFailThreshold || score >= cfg.scoreThreshold) consider(ip, score, "auth_brute_force", snap.tcpTotal.get(ip) || arr.length);
  }

  for (const [ip, count] of snap.udpTotal) {
    const old = prevUdp.get(ip) ?? count;
    const delta = Math.max(0, count - old);
    prevUdp.set(ip, count);
    const score = Math.min(100, Math.round((count / cfg.udpThreshold) * 60 + (delta / 30) * 40));
    if (count >= cfg.udpThreshold || score >= cfg.scoreThreshold) consider(ip, score, "udp_flood_signal", count);
  }

  const sorted = [...attackers.values()].sort((a, b) => b.score - a.score);
  const actions = [];
  for (const a of sorted) {
    if (a.score >= cfg.scoreThreshold || a.reason.endsWith("_flood") || a.reason === "port_scan" || a.reason === "auth_brute_force") {
      actions.push({ ip: a.ip, reason: a.reason, score: a.score, decision: "block" });
    } else {
      actions.push({ ip: a.ip, reason: a.reason, score: a.score, decision: "watch" });
    }
  }
  return { actions, totalConn };
}

function freshState() {
  return { prevConn: new Map(), prevSyn: new Map(), portsSeen: new Map(), authFail: new Map(), prevUdp: new Map() };
}

// --- Scenario 1: SYN flood from one IP, nothing else suspicious ---
{
  const state = freshState();
  const snap = { tcpTotal: new Map([["203.0.113.9", 5]]), tcpSyn: new Map([["203.0.113.9", 50]]), scanPorts: new Map(), udpTotal: new Map() };
  const { actions } = runDetectors(snap, [], state);
  assert.equal(actions.length, 1, "exactly one attacker flagged");
  assert.equal(actions[0].ip, "203.0.113.9");
  assert.equal(actions[0].reason, "syn_flood");
  assert.equal(actions[0].decision, "block", "SYN flood blocks even below the general score threshold, since it's flood-tagged");
}
console.log("PASS: SYN flood scenario blocks correctly");

// --- Scenario 2: Port scan, low connection count (the whole point of port
// scans — few connections, many distinct ports) ---
{
  const state = freshState();
  const ports = new Set(Array.from({length: 20}, (_, i) => 1000 + i));
  const snap = { tcpTotal: new Map([["198.51.100.4", 3]]), tcpSyn: new Map(), scanPorts: new Map([["198.51.100.4", ports]]), udpTotal: new Map() };
  const { actions } = runDetectors(snap, [], state);
  assert.equal(actions.length, 1);
  assert.equal(actions[0].reason, "port_scan");
  assert.equal(actions[0].decision, "block", "port scan blocks despite low connection count — this is the case the connection-flood detector alone would MISS");
}
console.log("PASS: Port scan detected even with low connection count (validates why this detector needed adding)");

// --- Scenario 3: SSH brute force, escalating over several ticks ---
{
  const state = freshState();
  const snap = { tcpTotal: new Map([["192.0.2.55", 1]]), tcpSyn: new Map(), scanPorts: new Map(), udpTotal: new Map() };
  let lastActions;
  for (let i = 0; i < 7; i++) {
    ({ actions: lastActions } = runDetectors(snap, ["192.0.2.55"], state));
  }
  assert.equal(lastActions.length, 1);
  assert.equal(lastActions[0].reason, "auth_brute_force");
  assert.equal(lastActions[0].decision, "block", "7 failed logins (>= authFailThreshold of 6) triggers a block");
}
console.log("PASS: SSH brute-force accumulates across ticks and blocks at threshold");

// --- Scenario 4: legitimate-looking traffic should NOT trigger anything ---
{
  const state = freshState();
  const snap = { tcpTotal: new Map([["1.2.3.4", 3], ["5.6.7.8", 8]]), tcpSyn: new Map(), scanPorts: new Map([["1.2.3.4", new Set([443])], ["5.6.7.8", new Set([443, 80])]]), udpTotal: new Map() };
  const { actions } = runDetectors(snap, [], state);
  assert.equal(actions.length, 0, "normal low-volume traffic produces zero flagged attackers");
}
console.log("PASS: normal traffic produces no false positives");

// --- Scenario 5: UDP flood signal ---
{
  const state = freshState();
  const snap = { tcpTotal: new Map(), tcpSyn: new Map(), scanPorts: new Map(), udpTotal: new Map([["203.0.113.200", 250]]) };
  const { actions } = runDetectors(snap, [], state);
  assert.equal(actions.length, 1);
  assert.equal(actions[0].reason, "udp_flood_signal");
  assert.equal(actions[0].decision, "block");
}
console.log("PASS: UDP flood signal scenario");

// --- Scenario 6: multiple simultaneous attackers, sorted by score ---
{
  const state = freshState();
  const snap = {
    tcpTotal: new Map([["1.1.1.1", 200], ["2.2.2.2", 5]]),
    tcpSyn: new Map([["2.2.2.2", 45]]),
    scanPorts: new Map(),
    udpTotal: new Map()
  };
  const { actions } = runDetectors(snap, [], state);
  assert.equal(actions.length, 2, "both attackers flagged independently");
  assert.ok(actions[0].score >= actions[1].score, "results sorted by descending score");
}
console.log("PASS: multiple simultaneous attackers, correctly sorted");

console.log("\nALL TICK-LOGIC SCENARIO TESTS PASSED");

// --- Scenario 7: HTTP flood — high request rate from one IP, low raw
// connection count (the case that would slip past connection/SYN detectors) ---
{
  const cfg2 = { ...cfg, httpFloodThreshold: 300 };
  function runWithHttp(snap, httpIPs, state) {
    const { httpReq } = state;
    const now = Date.now();
    const attackers = new Map();
    function consider(ip, score, reason, connCount) {
      const existing = attackers.get(ip);
      if (!existing || score > existing.score) attackers.set(ip, { ip, score, reason, connections: connCount });
    }
    for (const ip of httpIPs) {
      let arr = httpReq.get(ip);
      if (!arr) { arr = []; httpReq.set(ip, arr); }
      arr.push(now);
    }
    for (const [ip, arr] of httpReq) {
      const score = Math.min(100, Math.round((arr.length / cfg2.httpFloodThreshold) * 100));
      if (arr.length >= cfg2.httpFloodThreshold || score >= cfg2.scoreThreshold) {
        consider(ip, score, "http_flood", snap.tcpTotal.get(ip) || arr.length);
      }
    }
    return [...attackers.values()];
  }
  const state = { httpReq: new Map() };
  const snap = { tcpTotal: new Map([["203.0.113.50", 4]]) }; // only 4 raw connections — would NOT trip connection_flood (threshold 120)
  const floodedIPs = Array(350).fill("203.0.113.50"); // 350 requests, one tick, well past threshold 300
  const results = runWithHttp(snap, floodedIPs, state);
  assert.equal(results.length, 1);
  assert.equal(results[0].reason, "http_flood");
  assert.equal(results[0].connections, 4, "reports the real low connection count, not the request count, when available");
  assert.ok(results[0].score >= 60, "score crosses the block threshold");
}
console.log("PASS: HTTP flood detected despite low raw connection count (validates the detector catches what connection/SYN detectors structurally cannot)");

console.log("\nALL TICK-LOGIC SCENARIO TESTS PASSED (including HTTP flood)");
