#!/usr/bin/env bash
# test-install-sh.sh — regression test for install.sh, run with:
#   bash tests/test-install-sh.sh
#
# Covers two real bugs found while building this: (1) install.sh used to
# silently produce an EMPTY install directory on any host where /bin/sh is
# dash — which is the Ubuntu/Debian default, not an edge case — because it
# used bash-only brace-expansion (cp {a,b,c}) that dash treats as a single
# literal filename. (2) if invoked with `sh install.sh` by mistake instead
# of `sudo ./install.sh`, it needs to fail with a clear, actionable
# message rather than a cryptic shell error.
#
# This test does NOT run the real install (that needs root + system
# mutation); it checks the specific properties that caused the original
# failures, so a future edit that reintroduces either problem gets caught
# here instead of silently shipping again.

set -euo pipefail
FAILED=0
PASS() { echo "PASS: $1"; }
FAIL() { echo "FAIL: $1"; FAILED=1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_SH="$SCRIPT_DIR/install.sh"

if [ ! -f "$INSTALL_SH" ]; then
  echo "Cannot find install.sh at $INSTALL_SH"
  exit 1
fi

# --- Test 1: no bash-only brace expansion in any cp/mv command ---
# This is what actually broke: cp -r foo/{a,b,c} dest/ is silently
# mis-parsed by dash as a single filename containing literal braces,
# and the file simply doesn't get copied — no error, no missing-file
# complaint, just an empty destination. Grepping for the pattern directly
# catches a regression even if no test happens to run under dash.
if grep -qE '(cp|mv) .*\{[a-zA-Z0-9_.]+,[a-zA-Z0-9_.]+' "$INSTALL_SH"; then
  FAIL "install.sh contains bash-only brace expansion in a cp/mv command — this silently breaks under dash (Ubuntu/Debian's default /bin/sh)"
else
  PASS "no bash-only brace expansion in cp/mv commands"
fi

# --- Test 2: the bash-guard exists and is positioned before any bash-only
# syntax that would fail first with a confusing error (e.g. `set -o
# pipefail`, which dash rejects outright before the friendly guard could
# ever run) ---
GUARD_LINE="$(grep -n 'BASH_VERSION' "$INSTALL_SH" | head -1 | cut -d: -f1)"
PIPEFAIL_LINE="$(grep -n 'set -.*pipefail' "$INSTALL_SH" | head -1 | cut -d: -f1)"
if [ -z "$GUARD_LINE" ]; then
  FAIL "no BASH_VERSION guard found in install.sh"
elif [ -n "$PIPEFAIL_LINE" ] && [ "$PIPEFAIL_LINE" -lt "$GUARD_LINE" ]; then
  FAIL "set -o pipefail (line $PIPEFAIL_LINE) appears before the bash guard (line $GUARD_LINE) — dash will fail on pipefail with a cryptic error before the friendly guard message can print"
else
  PASS "bash guard is positioned before any bash-only options that could fail first"
fi

# --- Test 3: actually invoke the script with sh and confirm it fails
# fast with the intended message, not a shell parse error ---
if command -v dash >/dev/null 2>&1; then
  OUTPUT="$(dash "$INSTALL_SH" 2>&1 || true)"
  if echo "$OUTPUT" | grep -q "needs bash"; then
    PASS "running with dash produces the intended clear error message"
  else
    FAIL "running with dash did not produce the expected guard message. Got: $OUTPUT"
  fi
else
  echo "SKIP: dash not available in this environment to test directly"
fi

# --- Test 4: every file install.sh's cp loop expects to exist actually
# exists in this project — catches the file list and the project layout
# drifting apart silently ---
REQUIRED_FILES="agent.js server.js setup.js package.json kernel-hardening.sh"
for f in $REQUIRED_FILES; do
  if grep -q "\b$f\b" "$INSTALL_SH" && [ ! -f "$SCRIPT_DIR/$f" ]; then
    FAIL "install.sh references $f but it does not exist in the project"
  fi
done
PASS "all files install.sh expects to copy actually exist in the project"

echo ""
if [ "$FAILED" -eq 0 ]; then
  echo "ALL INSTALL.SH REGRESSION TESTS PASSED"
  exit 0
else
  echo "SOME INSTALL.SH REGRESSION TESTS FAILED"
  exit 1
fi
