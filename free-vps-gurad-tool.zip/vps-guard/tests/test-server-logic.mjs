import assert from "node:assert/strict";
import crypto from "node:crypto";

// --- Reimplementation of the pure logic from server.js, to unit-test
// without needing express/helmet/express-session installed ---

function timingSafeStrEqual(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

function passwordOK(password, cfg) {
  const candidate = crypto.scryptSync(password, cfg.salt, 64);
  const stored = Buffer.from(cfg.passwordHash, "hex");
  return candidate.length === stored.length && crypto.timingSafeEqual(candidate, stored);
}

// Exact input-cleaning logic from /api/login in server.js, extracted for
// testing. Fixes a real reported issue: a trailing newline from copy-paste
// (text file, terminal, password manager) or stray whitespace around the
// username both silently failed login with no way to tell why.
function cleanLoginInput(rawUsername, rawPassword) {
  const username = String(rawUsername || "").trim();
  const password = String(rawPassword || "").replace(/[\r\n]+$/, "");
  return { username, password };
}

const VALID_REASONS = new Set([
  "connection_flood", "connection_flood_watch", "syn_flood", "port_scan",
  "auth_brute_force", "udp_flood_signal", "http_flood", "observe"
]);

// --- Tests ---

// timingSafeStrEqual
assert.equal(timingSafeStrEqual("abc", "abc"), true, "equal strings match");
assert.equal(timingSafeStrEqual("abc", "abd"), false, "different strings do not match");
assert.equal(timingSafeStrEqual("abc", "abcd"), false, "different length strings do not match, no throw");
assert.equal(timingSafeStrEqual("", ""), true, "empty strings match");
assert.equal(timingSafeStrEqual("", "x"), false, "empty vs non-empty");
console.log("PASS: timingSafeStrEqual");

// passwordOK — real scrypt roundtrip like setup.js produces
const salt = crypto.randomBytes(16).toString("hex");
const realPassword = "verysecurepassword123";
const hash = crypto.scryptSync(realPassword, salt, 64).toString("hex");
const cfg = { salt, passwordHash: hash };
assert.equal(passwordOK(realPassword, cfg), true, "correct password accepted");
assert.equal(passwordOK("wrongpassword", cfg), false, "wrong password rejected");
assert.equal(passwordOK("", cfg), false, "empty password rejected");
console.log("PASS: passwordOK");

// Login input cleaning — the actual fix for reported "username/password
// doesn't work" cases traced to copy-paste artifacts, not broken auth.
assert.deepEqual(
  cleanLoginInput("admin", `${realPassword}\n`),
  { username: "admin", password: realPassword },
  "trailing newline in pasted password is stripped"
);
assert.deepEqual(
  cleanLoginInput("admin", `${realPassword}\r\n`),
  { username: "admin", password: realPassword },
  "trailing CRLF (common on Windows-copied text) is stripped"
);
assert.deepEqual(
  cleanLoginInput("  admin  ", realPassword),
  { username: "admin", password: realPassword },
  "leading/trailing whitespace around username (autofill artifact) is trimmed"
);
assert.deepEqual(
  cleanLoginInput("admin", `  ${realPassword}  `),
  { username: "admin", password: `  ${realPassword}  ` },
  "whitespace INSIDE/around the password body (not a trailing newline) is preserved — could be intentional, only newline artifacts are stripped"
);
// After cleaning, the real auth check must still correctly accept the
// genuine password and still correctly reject a genuinely wrong one —
// the fix must not have loosened security, only tolerance for harmless
// copy-paste noise.
{
  const cleaned = cleanLoginInput("admin", `${realPassword}\n`);
  assert.equal(passwordOK(cleaned.password, cfg), true, "cleaned genuine password still authenticates");
}
{
  const cleaned = cleanLoginInput("admin", "totallywrongpassword\n");
  assert.equal(passwordOK(cleaned.password, cfg), false, "cleaning does not make a genuinely wrong password pass");
}
console.log("PASS: login input cleaning (fixes reported login failures without loosening auth)");

// VALID_REASONS filtering (as used in /api/report)
function sanitizeReason(r) { return VALID_REASONS.has(r) ? r : "observe"; }
assert.equal(sanitizeReason("syn_flood"), "syn_flood");
assert.equal(sanitizeReason("port_scan"), "port_scan");
assert.equal(sanitizeReason("auth_brute_force"), "auth_brute_force");
assert.equal(sanitizeReason("udp_flood_signal"), "udp_flood_signal");
assert.equal(sanitizeReason("connection_flood"), "connection_flood");
assert.equal(sanitizeReason("connection_flood_watch"), "connection_flood_watch");
assert.equal(sanitizeReason("<script>alert(1)</script>"), "observe", "malicious/unexpected reason strings get sanitized");
assert.equal(sanitizeReason(undefined), "observe", "missing reason defaults safely");
console.log("PASS: reason sanitization");

// IP regex used to validate attacker.ip in /api/report — must accept real
// IPv4/IPv6 and reject junk that could be used for injection
const ipRe = /^[0-9a-fA-F:.]{3,80}$/;
assert.equal(ipRe.test("192.168.1.1"), true);
assert.equal(ipRe.test("2001:db8::1"), true);
assert.equal(ipRe.test("::1"), true);
assert.equal(ipRe.test("8.8.8.8"), true);
assert.equal(ipRe.test("<script>"), false, "rejects script tags");
assert.equal(ipRe.test("'; DROP TABLE"), false, "rejects sql-injection-shaped strings");
assert.equal(ipRe.test("a".repeat(90)), false, "rejects overlong strings");
console.log("PASS: IP validation regex");

// agentTokens multi-token lookup logic (from requireAgent)
function findAgentToken(supplied, agentTokens) {
  for (const token of agentTokens.keys()) {
    if (timingSafeStrEqual(supplied, token)) return true;
  }
  return false;
}
const tokenMap = new Map([["tokenA", "vps-1"], ["tokenB", "vps-2"], ["tokenC", "vps-3"]]);
assert.equal(findAgentToken("tokenB", tokenMap), true, "valid token from the set is accepted");
assert.equal(findAgentToken("tokenX", tokenMap), false, "token not in the set is rejected");
assert.equal(findAgentToken("", tokenMap), false, "empty token rejected");
console.log("PASS: multi-agent token lookup");

console.log("\nALL SERVER LOGIC TESTS PASSED");
