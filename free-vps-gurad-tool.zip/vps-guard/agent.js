import fs from "node:fs";
import os from "node:os";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const exec = promisify(execFile);
const cfg = JSON.parse(fs.readFileSync(new URL("./config.json", import.meta.url), "utf8"));
const SERVER = process.env.VPS_GURAD_SERVER || `http://${cfg.host}:${cfg.port}`;
const INTERVAL = 5000;
const agentId = process.env.VPS_GURAD_AGENT_ID || `${os.hostname()}-${crypto.randomUUID()}`;
const agentToken = process.env.VPS_GURAD_AGENT_TOKEN || cfg.internalToken;

// Per-agent bounded state. Every Map here has an explicit cap so memory
// can never grow unbounded on a VPS under real attack (that would itself
// become a resource-exhaustion problem, which defeats the point).
const blocked = new Map();          // ip -> unblock timestamp
const prevConn = new Map();         // ip -> last total connection count (connection-flood delta)
const prevSyn = new Map();          // ip -> last SYN-RECV count (SYN-flood delta)
const portsSeen = new Map();        // ip -> Set of distinct ports touched recently (port-scan)
const authFail = new Map();         // ip -> [timestamps] of recent failed logins (brute force)
const prevUdp = new Map();          // ip -> last UDP packet-ish count (UDP-flood signal)
const httpReq = new Map();          // ip -> [timestamps] of recent HTTP requests (L7 flood)
const MAX_TRACKED = 5000;
const MAX_PORTS_PER_IP = 40;        // stop growing a single IP's port-set past this; it's already a scan
const AUTH_WINDOW_MS = 10 * 60 * 1000;
const HTTP_WINDOW_MS = 60 * 1000;   // HTTP floods move fast; a 1-minute window catches them quicker than the 10-minute auth window

let authCursor = null; // journalctl --since cursor so we never re-read the whole log each tick
let httpLogPath = null;   // resolved once at startup; null if no known web-server log is found
let httpLogOffset = 0;    // byte offset into httpLogPath already processed

function capMap(map, max = MAX_TRACKED) {
  while (map.size > max) map.delete(map.keys().next().value);
}

function privateIP(ip) {
  if (ip === "127.0.0.1" || ip === "::1" || ip === "0.0.0.0" || ip === "::") return true;
  if (/^10\./.test(ip) || /^192\.168\./.test(ip)) return true;
  const m = ip.match(/^172\.(\d+)\./);
  return !!(m && +m[1] >= 16 && +m[1] <= 31);
}

function ipPortFromSs(line) {
  // Returns { ip, port } for the remote (last) address:port field on a ss
  // line. Handles three real-world forms:
  //   - bracketed IPv6 (the documented, unambiguous form): [2001:db8::5]:443
  //   - plain IPv4: 203.0.113.7:51422
  //   - unbracketed IPv6, seen on some ss/iproute2 builds: 2001:db8::5:443
  // Wildcard tokens (*:*, :::*) are skipped rather than misparsed.
  const parts = line.trim().split(/\s+/);
  for (let i = parts.length - 1; i >= 0; i--) {
    const x = parts[i];
    let m = x.match(/^\[([0-9a-fA-F:]+)\]:(\d+)$/);
    if (m) return { ip: m[1], port: +m[2] };
    m = x.match(/^(\d+\.\d+\.\d+\.\d+):(\d+)$/);
    if (m) return { ip: m[1], port: +m[2] };
    if (x === "*:*" || x === ":::*" || /^\*:/.test(x)) continue;
    const lastColon = x.lastIndexOf(":");
    if (lastColon > 0) {
      const addr = x.slice(0, lastColon);
      const portStr = x.slice(lastColon + 1);
      if (/^\d+$/.test(portStr) && (addr.match(/:/g) || []).length >= 2 && /^[0-9a-fA-F:]+$/.test(addr) && addr !== "*") {
        return { ip: addr, port: +portStr };
      }
    }
  }
  return null;
}

// One combined snapshot per tick instead of one `ss` invocation per detector.
// Keeps this at exactly 2 subprocess spawns/tick on Linux (TCP + UDP) no
// matter how many detectors are layered on top.
async function snapshotLinux() {
  const tcpTotal = new Map();   // ip -> total established/other conn count
  const tcpSyn = new Map();     // ip -> SYN-RECV count (half-open, classic SYN flood signal)
  const scanPorts = new Map();  // ip -> Set(ports touched)
  const udpTotal = new Map();   // ip -> udp socket count

  try {
    const { stdout } = await exec("ss", ["-Htan"], { timeout: 2000, maxBuffer: 4e6 });
    for (const line of stdout.split("\n")) {
      if (!line.trim()) continue;
      const state = line.trim().split(/\s+/)[0];
      const rp = ipPortFromSs(line);
      if (!rp || privateIP(rp.ip)) continue;
      tcpTotal.set(rp.ip, (tcpTotal.get(rp.ip) || 0) + 1);
      if (/syn-recv/i.test(state)) tcpSyn.set(rp.ip, (tcpSyn.get(rp.ip) || 0) + 1);
      let set = scanPorts.get(rp.ip);
      if (!set) { set = new Set(); scanPorts.set(rp.ip, set); }
      if (set.size < MAX_PORTS_PER_IP) set.add(rp.port);
    }
  } catch {}

  try {
    const { stdout } = await exec("ss", ["-Huan"], { timeout: 2000, maxBuffer: 4e6 });
    for (const line of stdout.split("\n")) {
      if (!line.trim()) continue;
      const rp = ipPortFromSs(line);
      if (!rp || privateIP(rp.ip)) continue;
      udpTotal.set(rp.ip, (udpTotal.get(rp.ip) || 0) + 1);
    }
  } catch {}

  return { tcpTotal, tcpSyn, scanPorts, udpTotal };
}

async function snapshotWindows() {
  const tcpTotal = new Map();
  const tcpSyn = new Map();
  const udpTotal = new Map();
  const scanPorts = new Map();
  try {
    const ps = "Get-NetTCPConnection | Select-Object State,RemoteAddress,RemotePort | " +
      "ForEach-Object { \"$($_.State)|$($_.RemoteAddress)|$($_.RemotePort)\" }";
    const { stdout } = await exec("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", ps], { timeout: 2500, maxBuffer: 4e6 });
    for (const line of stdout.split(/\r?\n/)) {
      const [state, ip, portStr] = line.trim().split("|");
      if (!ip || privateIP(ip)) continue;
      tcpTotal.set(ip, (tcpTotal.get(ip) || 0) + 1);
      if (/SynReceived/i.test(state || "")) tcpSyn.set(ip, (tcpSyn.get(ip) || 0) + 1);
      let set = scanPorts.get(ip);
      if (!set) { set = new Set(); scanPorts.set(ip, set); }
      const port = +portStr;
      if (port && set.size < MAX_PORTS_PER_IP) set.add(port);
    }
  } catch {}
  try {
    const ps = "Get-NetUDPEndpoint | Select-Object -ExpandProperty RemoteAddress";
    const { stdout } = await exec("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", ps], { timeout: 2500, maxBuffer: 4e6 });
    for (const line of stdout.split(/\r?\n/)) {
      const ip = line.trim();
      if (!ip || privateIP(ip)) continue;
      udpTotal.set(ip, (udpTotal.get(ip) || 0) + 1);
    }
  } catch {}
  return { tcpTotal, tcpSyn, scanPorts, udpTotal };
}

// SSH / login brute-force detection via journalctl (falls back silently if
// unavailable — e.g. non-systemd hosts). Uses a cursor so each tick only
// reads *new* lines, never the whole auth log.
async function authFailures() {
  const found = [];
  try {
    const args = ["-u", "sshd", "-u", "ssh", "-o", "cat", "--no-pager"];
    if (authCursor) args.unshift("--after-cursor", authCursor);
    else args.unshift("--since", "-15s");
    args.push("--show-cursor");
    const { stdout } = await exec("journalctl", args, { timeout: 2000, maxBuffer: 2e6 });
    const lines = stdout.split("\n");
    for (const line of lines) {
      const cm = line.match(/^-- cursor: (.+)$/);
      if (cm) { authCursor = cm[1].trim(); continue; }
      if (!/Failed password|authentication failure|Invalid user/i.test(line)) continue;
      const m = line.match(/from (\d{1,3}(?:\.\d{1,3}){3}|[0-9a-fA-F:]+)\b/);
      if (m && !privateIP(m[1])) found.push(m[1]);
    }
  } catch {
    // journalctl not present or sshd not journald-logged (e.g. some containers,
    // or plain /var/log/auth.log setups) — brute-force detection degrades to
    // "no signal" rather than crashing the agent.
  }
  return found;
}

// HTTP flood (Layer-7) detection. Reads nginx/Apache access logs incrementally
// (byte-offset tracked, never re-reads from the start) and counts requests
// per source IP in a rolling window. This exists because raw TCP connection
// counts and Layer-7 request floods are different signals: a flood tool can
// hold very few concurrent connections open while firing a high rate of
// real, complete HTTP requests down each one (or opening/closing fast) —
// that traffic looks unremarkable to the connection-flood and SYN-flood
// detectors, which only see connection *counts*, not request *rate*.
// Silently produces no signal if no known web-server log is found — this
// VPS may not run a web server at all, which is a normal, healthy state
// for this detector to be in, not an error.
const HTTP_LOG_CANDIDATES = [
  "/var/log/nginx/access.log",
  "/var/log/apache2/access.log",
  "/var/log/httpd/access_log"
];
const HTTP_LOG_MAX_READ_BYTES = 2_000_000; // cap how much one tick will read even if the log grew enormously, to bound memory/CPU for that tick

function resolveHttpLogPath() {
  for (const candidate of HTTP_LOG_CANDIDATES) {
    try { if (fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  return null;
}

function extractIPFromLogLine(line) {
  // Common/Combined Log Format (shared by nginx and Apache):
  //   IP - user [date] "METHOD path HTTP/ver" status bytes "referer" "agent"
  // The IP is always the first field, followed by two more fields and a
  // bracketed date — that shape is what the regex anchors on.
  const m = line.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|[0-9a-fA-F:]+)\s+\S+\s+\S+\s+\[/);
  return m ? m[1] : null;
}

async function httpFloodIPs() {
  if (httpLogPath === null) {
    // Only resolved once at startup (see bottom of file) — if it was never
    // found, there's nothing to tail this or any future tick.
    return [];
  }
  let stat;
  try { stat = fs.statSync(httpLogPath); } catch { return []; }
  if (stat.size < httpLogOffset) httpLogOffset = 0; // log was rotated/truncated — restart from the new beginning rather than erroring or going silent forever
  if (stat.size === httpLogOffset) return [];
  const found = [];
  try {
    const fd = fs.openSync(httpLogPath, "r");
    const len = Math.min(stat.size - httpLogOffset, HTTP_LOG_MAX_READ_BYTES);
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, httpLogOffset);
    fs.closeSync(fd);
    httpLogOffset += len;
    for (const line of buf.toString("utf8").split("\n")) {
      if (!line) continue;
      const ip = extractIPFromLogLine(line);
      if (ip && !privateIP(ip)) found.push(ip);
    }
  } catch {
    // Permission issue, or log rotated out from under us mid-read — degrade
    // to "no signal" for this tick rather than crashing the agent.
  }
  return found;
}

async function firewall(action, ip) {
  if (!ip) return false;
  try {
    if (process.platform === "win32") {
      if (action === "block") await exec("netsh.exe", ["advfirewall", "firewall", "add", "rule", `name=VPSGurad ${ip}`, "dir=in", "action=block", `remoteip=${ip}`], { timeout: 3000 });
      else await exec("netsh.exe", ["advfirewall", "firewall", "delete", "rule", `name=VPSGurad ${ip}`], { timeout: 3000 });
      return true;
    }
    await exec("iptables", ["-N", "VPS_GURAD"], { timeout: 3000 }).catch(() => {});
    await exec("iptables", ["-C", "INPUT", "-j", "VPS_GURAD"], { timeout: 3000 })
      .catch(async () => exec("iptables", ["-I", "INPUT", "-j", "VPS_GURAD"], { timeout: 3000 }));
    if (action === "block")
      await exec("iptables", ["-C", "VPS_GURAD", "-s", ip, "-j", "DROP"], { timeout: 3000 })
        .catch(async () => exec("iptables", ["-I", "VPS_GURAD", "-s", ip, "-j", "DROP"], { timeout: 3000 }));
    else await exec("iptables", ["-D", "VPS_GURAD", "-s", ip, "-j", "DROP"], { timeout: 3000 }).catch(() => {});
    return true;
  } catch { return false; }
}

function cpu() {
  const cs = os.cpus();
  let idle = 0, total = 0;
  for (const c of cs) { idle += c.times.idle; total += Object.values(c.times).reduce((a, b) => a + b, 0); }
  return Math.round((1 - idle / Math.max(total, 1)) * 100);
}

async function blockIfNeeded(ip, score, reason, connCount, attackers) {
  if (blocked.has(ip)) {
    attackers.push({ ip, score, connections: connCount, action: "blocked", reason });
    return;
  }
  if (await firewall("block", ip)) {
    blocked.set(ip, Date.now() + cfg.blockSeconds * 1000);
    attackers.push({ ip, score, connections: connCount, action: "blocked", reason });
  } else {
    attackers.push({ ip, score, connections: connCount, action: "block_failed", reason });
  }
}

async function tick() {
  const snap = process.platform === "win32" ? await snapshotWindows() : await snapshotLinux();
  const failIPs = process.platform === "win32" ? [] : await authFailures();
  const httpIPs = await httpFloodIPs();

  const attackers = new Map(); // ip -> best (highest-score) attacker record this tick
  const now = Date.now();
  let totalConn = 0;

  function consider(ip, score, reason, connCount) {
    const existing = attackers.get(ip);
    if (!existing || score > existing.score) attackers.set(ip, { ip, score, reason, connections: connCount });
  }

  // 1) Connection-flood (rate of new connections, same heuristic as before)
  for (const [ip, count] of snap.tcpTotal) {
    totalConn += count;
    const old = prevConn.get(ip) ?? count;
    const delta = Math.max(0, count - old);
    prevConn.set(ip, count);
    const score = Math.min(100, Math.round((count / cfg.connectionThreshold) * 65 + (delta / 40) * 35));
    if (count >= cfg.connectionThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "connection_flood", count);
    } else if (score >= 30) {
      consider(ip, score, "connection_flood_watch", count);
    }
  }
  capMap(prevConn);

  // 2) SYN-flood (half-open connection burst — classic resource-exhaustion attack)
  for (const [ip, synCount] of snap.tcpSyn) {
    const old = prevSyn.get(ip) ?? synCount;
    const delta = Math.max(0, synCount - old);
    prevSyn.set(ip, synCount);
    const score = Math.min(100, Math.round((synCount / cfg.synThreshold) * 70 + (delta / 15) * 30));
    if (synCount >= cfg.synThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "syn_flood", snap.tcpTotal.get(ip) || synCount);
    }
  }
  capMap(prevSyn);

  // 3) Port-scan (many distinct destination ports from one source, fast)
  for (const [ip, set] of snap.scanPorts) {
    const prevSet = portsSeen.get(ip);
    const growth = prevSet ? Math.max(0, set.size - prevSet.size) : 0;
    portsSeen.set(ip, set);
    const score = Math.min(100, Math.round((set.size / cfg.portScanThreshold) * 60 + (growth / 8) * 40));
    if (set.size >= cfg.portScanThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "port_scan", snap.tcpTotal.get(ip) || set.size);
    }
  }
  capMap(portsSeen);

  // 4) SSH / login brute force (failed-auth attempts per IP in a rolling window)
  for (const ip of failIPs) {
    let arr = authFail.get(ip);
    if (!arr) { arr = []; authFail.set(ip, arr); }
    arr.push(now);
    while (arr.length && now - arr[0] > AUTH_WINDOW_MS) arr.shift();
  }
  for (const [ip, arr] of authFail) {
    while (arr.length && now - arr[0] > AUTH_WINDOW_MS) arr.shift();
    if (!arr.length) { authFail.delete(ip); continue; }
    const score = Math.min(100, Math.round((arr.length / cfg.authFailThreshold) * 100));
    if (arr.length >= cfg.authFailThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "auth_brute_force", snap.tcpTotal.get(ip) || arr.length);
    }
  }
  capMap(authFail);

  // 5) UDP-flood signal. UDP is connectionless, so this counts recent
  // sockets/datagram bursts as a *signal*, not proof — worth flagging,
  // not worth over-claiming certainty about.
  for (const [ip, count] of snap.udpTotal) {
    const old = prevUdp.get(ip) ?? count;
    const delta = Math.max(0, count - old);
    prevUdp.set(ip, count);
    const score = Math.min(100, Math.round((count / cfg.udpThreshold) * 60 + (delta / 30) * 40));
    if (count >= cfg.udpThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "udp_flood_signal", count);
    }
  }
  capMap(prevUdp);

  // 6) HTTP flood (Layer-7). Same rolling-window shape as SSH brute force,
  // but a much shorter window (60s vs 10min) since request floods escalate
  // far faster than credential-stuffing attempts, and a request-count
  // threshold rather than a failure-count one, since every request counts
  // here, not just failed ones.
  for (const ip of httpIPs) {
    let arr = httpReq.get(ip);
    if (!arr) { arr = []; httpReq.set(ip, arr); }
    arr.push(now);
    while (arr.length && now - arr[0] > HTTP_WINDOW_MS) arr.shift();
  }
  for (const [ip, arr] of httpReq) {
    while (arr.length && now - arr[0] > HTTP_WINDOW_MS) arr.shift();
    if (!arr.length) { httpReq.delete(ip); continue; }
    const score = Math.min(100, Math.round((arr.length / cfg.httpFloodThreshold) * 100));
    if (arr.length >= cfg.httpFloodThreshold || score >= cfg.scoreThreshold) {
      consider(ip, score, "http_flood", snap.tcpTotal.get(ip) || arr.length);
    }
  }
  capMap(httpReq);

  // Act: block anything that crossed a threshold, in score order.
  const finalAttackers = [];
  const sorted = [...attackers.values()].sort((a, b) => b.score - a.score);
  for (const a of sorted) {
    if (a.score >= cfg.scoreThreshold || a.reason.endsWith("_flood") || a.reason === "port_scan" || a.reason === "auth_brute_force") {
      await blockIfNeeded(a.ip, a.score, a.reason, a.connections, finalAttackers);
    } else {
      finalAttackers.push({ ip: a.ip, score: a.score, connections: a.connections, action: "watch", reason: a.reason });
    }
  }

  // Expire blocks whose window has passed.
  for (const [ip, until] of blocked) if (now >= until) { await firewall("unblock", ip); blocked.delete(ip); }

  const report = {
    agentId, hostname: os.hostname(), os: `${process.platform} ${os.release()}`,
    connections: totalConn, blocked: blocked.size, cpu: cpu(),
    memory: Math.round(process.memoryUsage().rss / 104857.6) / 10,
    attackers: finalAttackers.slice(0, 100),
    message: `${totalConn} conns | ${finalAttackers.length} suspicious | ${blocked.size} blocked`
  };
  try {
    await fetch(`${SERVER}/api/report`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-vps-gurad-agent": agentToken },
      body: JSON.stringify(report),
      signal: AbortSignal.timeout(2500)
    });
  } catch {}
}

httpLogPath = process.platform === "win32" ? null : resolveHttpLogPath();
console.log(`VPS Gurad agent ${agentId} on ${process.platform} -> ${SERVER}`);
console.log(httpLogPath ? `HTTP flood detection: watching ${httpLogPath}` : "HTTP flood detection: no nginx/Apache access log found (this is normal if this VPS doesn't serve HTTP)");
setInterval(() => tick().catch(() => {}), INTERVAL);
tick().catch(() => {});
