# Running VPS Gurad 24/7 with systemd

Two separate services: `vps-gurad-agent.service` runs on every protected
VPS. `vps-gurad-dashboard.service` runs once, on whichever box hosts the
central dashboard (which can be the same VPS in a single-server setup, or
a separate box in a multi-VPS setup).

Both use `Restart=always`, so systemd brings them back up automatically
after a crash or a server reboot — this is what makes the tool genuinely
"24/7" rather than dependent on someone leaving a terminal session open.

## 1. Install the dashboard (once, wherever it lives)

```bash
sudo mkdir -p /opt/vps-guard
sudo cp -r server.js public agents.json config.json package.json /opt/vps-guard/
cd /opt/vps-guard && sudo npm install --omit=dev

# Dedicated unprivileged user — the dashboard has no need for root
sudo useradd --system --no-create-home --shell /usr/sbin/nologin vpsgurad
sudo chown -R vpsgurad:vpsgurad /opt/vps-guard

sudo cp systemd/vps-gurad-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now vps-gurad-dashboard
sudo systemctl status vps-gurad-dashboard
```

## 2. Install the agent (on every protected VPS)

```bash
sudo mkdir -p /opt/vps-guard
sudo cp agent.js kernel-hardening.sh config.json package.json /opt/vps-guard/
sudo chmod +x /opt/vps-guard/kernel-hardening.sh
cd /opt/vps-guard && sudo npm install --omit=dev

sudo cp systemd/vps-gurad-agent.service /etc/systemd/system/
```

Before starting, edit `/etc/systemd/system/vps-gurad-agent.service` and set
`VPS_GURAD_SERVER` to your real dashboard address. If this is a multi-VPS
setup, also uncomment and fill in `VPS_GURAD_AGENT_TOKEN` and
`VPS_GURAD_AGENT_ID` using one token/label pair from the dashboard's
`agents.json` (each VPS needs its own, unique pair):

```bash
sudo systemctl edit --full vps-gurad-agent
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now vps-gurad-agent
sudo systemctl status vps-gurad-agent
```

The agent's service definition automatically re-runs `kernel-hardening.sh`
on every start (via `ExecStartPre`), so the kernel-level rate limiting is
reapplied on every reboot without a separate step.

## Checking it's working

```bash
# Agent logs (attack detections, blocks, HTTP-flood log path found/not found)
sudo journalctl -u vps-gurad-agent -f

# Dashboard logs
sudo journalctl -u vps-gurad-dashboard -f

# Kernel-level rate limit hit counts
sudo /opt/vps-guard/kernel-hardening.sh --status
```

## Updating

```bash
sudo systemctl stop vps-gurad-agent      # or vps-gurad-dashboard
sudo cp <updated files> /opt/vps-guard/
sudo systemctl start vps-gurad-agent
```

## Fully removing

```bash
sudo systemctl disable --now vps-gurad-agent vps-gurad-dashboard
sudo rm /etc/systemd/system/vps-gurad-agent.service /etc/systemd/system/vps-gurad-dashboard.service
sudo systemctl daemon-reload
sudo /opt/vps-guard/kernel-hardening.sh --remove
sudo rm -rf /opt/vps-guard
sudo userdel vpsgurad
```
