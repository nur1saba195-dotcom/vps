#!/usr/bin/env bash
# install.sh — one-command install for VPS Gurad.
#
# WHAT THIS DOES
#   1. Copies the project into /opt/vps-guard
#   2. Installs npm dependencies
#   3. Runs setup.js interactively (admin username/password, agent count)
#      unless credentials already exist, in which case it skips straight
#      to re-applying config — see --reset-credentials to force a change
#   4. Creates the unprivileged dashboard system user
#   5. Installs kernel-level rate limiting (Linux)
#   6. Installs and starts both systemd services, with tokens threaded in
#      automatically — no manual copy-paste into the unit file
#   7. Prints ready-to-run commands for any additional VPS agents
#
# This script is the fix for "tokens don't match" / "forgot a step" class
# problems: every value setup.js generates flows straight into the running
# services without a human re-typing or copy-pasting it in between.
#
# USAGE
#   sudo ./install.sh                    install or update in place
#   sudo ./install.sh --reset-credentials force a fresh admin username/password
#   sudo ./install.sh --uninstall        stop services and remove everything
#   sudo ./install.sh --dashboard-only   install only the dashboard (for a
#                                        central box with no local agent)
#   sudo ./install.sh --agent-only       install only the agent (for an
#                                        additional VPS joining an existing
#                                        dashboard — prompts for the
#                                        dashboard URL, token, and label)

if [ -z "${BASH_VERSION:-}" ]; then
  echo "This script needs bash, not sh. Run it as:" >&2
  echo "  sudo bash $0" >&2
  echo "or make sure it's executable and run:" >&2
  echo "  sudo ./$(basename "$0")" >&2
  exit 1
fi

set -euo pipefail

INSTALL_DIR="/opt/vps-guard"
SERVICE_USER="vpsgurad"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="full"
RESET_CREDS="no"

while [ $# -gt 0 ]; do
  case "$1" in
    --uninstall) MODE="uninstall"; shift ;;
    --dashboard-only) MODE="dashboard-only"; shift ;;
    --agent-only) MODE="agent-only"; shift ;;
    --reset-credentials) RESET_CREDS="yes"; shift ;;
    -h|--help)
      echo "Usage: sudo $0 [--reset-credentials|--uninstall|--dashboard-only|--agent-only]"
      exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "This needs root. Run with sudo." >&2
  exit 1
fi

log() { echo -e "\n\033[1;32m==>\033[0m $1"; }
warn() { echo -e "\033[1;33mWARNING:\033[0m $1" >&2; }

# ---------------------------------------------------------------- uninstall
if [ "$MODE" = "uninstall" ]; then
  log "Stopping and removing VPS Gurad"
  systemctl disable --now vps-gurad-agent 2>/dev/null || true
  systemctl disable --now vps-gurad-dashboard 2>/dev/null || true
  rm -f /etc/systemd/system/vps-gurad-agent.service /etc/systemd/system/vps-gurad-dashboard.service
  systemctl daemon-reload
  if [ -x "$INSTALL_DIR/kernel-hardening.sh" ]; then
    "$INSTALL_DIR/kernel-hardening.sh" --remove || true
  fi
  read -r -p "Delete $INSTALL_DIR entirely, including config.json/agents.json? [y/N] " confirm
  if [[ "$confirm" =~ ^[Yy]$ ]]; then
    rm -rf "$INSTALL_DIR"
    echo "Removed $INSTALL_DIR"
  else
    echo "Left $INSTALL_DIR in place (services are stopped either way)."
  fi
  userdel "$SERVICE_USER" 2>/dev/null || true
  echo "Uninstall complete."
  exit 0
fi

# ------------------------------------------------------------- agent-only
if [ "$MODE" = "agent-only" ]; then
  if ! command -v node >/dev/null 2>&1; then
    echo "Node.js 20+ is required. Install it first, then re-run this script." >&2
    exit 1
  fi
  log "Installing agent-only (this VPS joins an existing dashboard)"
  mkdir -p "$INSTALL_DIR"
  cp "$SCRIPT_DIR/agent.js" "$SCRIPT_DIR/package.json" "$INSTALL_DIR/"
  [ -f "$SCRIPT_DIR/kernel-hardening.sh" ] && cp "$SCRIPT_DIR/kernel-hardening.sh" "$INSTALL_DIR/" && chmod +x "$INSTALL_DIR/kernel-hardening.sh"
  cd "$INSTALL_DIR" && npm install --omit=dev --no-audit --no-fund

  read -r -p "Dashboard URL (e.g. https://dashboard.example.com): " DASH_URL
  read -r -p "Agent token (from the dashboard's agents.json): " AGENT_TOKEN
  read -r -p "Agent label (e.g. vps-2, must match agents.json): " AGENT_LABEL

  mkdir -p /etc/vps-gurad
  cat > /etc/vps-gurad/agent.env <<EOF
VPS_GURAD_SERVER=${DASH_URL}
VPS_GURAD_AGENT_TOKEN=${AGENT_TOKEN}
VPS_GURAD_AGENT_ID=${AGENT_LABEL}
EOF
  chmod 600 /etc/vps-gurad/agent.env

  cp "$SCRIPT_DIR/systemd/vps-gurad-agent.service" /etc/systemd/system/
  # Point the unit at the env file instead of inline Environment= lines, so
  # the token never needs to be pasted into the unit file by hand.
  sed -i '/^Environment=VPS_GURAD/d' /etc/systemd/system/vps-gurad-agent.service
  if ! grep -q "^EnvironmentFile=" /etc/systemd/system/vps-gurad-agent.service; then
    sed -i '/^\[Service\]/a EnvironmentFile=/etc/vps-gurad/agent.env' /etc/systemd/system/vps-gurad-agent.service
  fi

  if [ -x "$INSTALL_DIR/kernel-hardening.sh" ]; then
    log "Installing kernel-level rate limiting"
    "$INSTALL_DIR/kernel-hardening.sh" || warn "kernel-hardening.sh failed — agent will still run without it"
  fi

  systemctl daemon-reload
  systemctl enable --now vps-gurad-agent
  sleep 1
  systemctl --no-pager status vps-gurad-agent || true
  log "Agent installed and running. Check it registered on the dashboard within ~10s."
  exit 0
fi

# --------------------------------------------------------- full / dashboard
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 20+ is required. Install it first (e.g. via nodesource or nvm), then re-run this script." >&2
  exit 1
fi
NODE_MAJOR="$(node -e 'console.log(process.versions.node.split(".")[0])')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "Node.js 20+ required, found $(node -v). Upgrade Node, then re-run." >&2
  exit 1
fi

log "Copying files to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
for f in agent.js server.js setup.js package.json kernel-hardening.sh; do
  if [ ! -f "$SCRIPT_DIR/$f" ]; then
    echo "Missing required file: $SCRIPT_DIR/$f — is this script being run from inside the extracted project folder?" >&2
    exit 1
  fi
  cp "$SCRIPT_DIR/$f" "$INSTALL_DIR/"
done
if [ ! -d "$SCRIPT_DIR/public" ]; then
  echo "Missing required directory: $SCRIPT_DIR/public" >&2
  exit 1
fi
cp -r "$SCRIPT_DIR/public" "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/kernel-hardening.sh"
[ -d "$SCRIPT_DIR/tests" ] && cp -r "$SCRIPT_DIR/tests" "$INSTALL_DIR/"

cd "$INSTALL_DIR"
log "Installing npm dependencies"
npm install --omit=dev --no-audit --no-fund

if [ -f "$INSTALL_DIR/config.json" ] && [ "$RESET_CREDS" = "no" ]; then
  log "Existing config.json found — keeping current admin credentials"
  echo "(Use --reset-credentials to change the admin username/password.)"
else
  if [ -f "$INSTALL_DIR/config.json" ]; then
    log "Resetting credentials (--reset-credentials was passed)"
  else
    log "Running first-time setup"
  fi
  node setup.js
fi

log "Creating unprivileged dashboard user"
id -u "$SERVICE_USER" >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
# The agent still needs root at runtime (firewall + privileged reads), so
# its own service unit sets User=root independently of this ownership —
# this chown only affects the dashboard's unprivileged process.

log "Installing kernel-level rate limiting"
"$INSTALL_DIR/kernel-hardening.sh" || warn "kernel-hardening.sh failed — continuing without it. Run it manually later: sudo $INSTALL_DIR/kernel-hardening.sh"

log "Installing systemd services"
# NOTE: this always overwrites the deployed unit files with the pristine
# template from this project, then re-fills in the token — so re-running
# install.sh is genuinely idempotent (this is deliberate; it's what makes
# --reset-credentials able to correctly re-thread a fresh token every time,
# rather than getting stuck trying to pattern-match an already-edited
# line). The one consequence: any manual edits made directly to the
# deployed /etc/systemd/system/vps-gurad-*.service files will be lost on
# the next install.sh run. If you need a permanent custom setting, add a
# systemd drop-in instead (`systemctl edit vps-gurad-agent`), which layers
# on top and survives re-installs.
cp "$SCRIPT_DIR/systemd/vps-gurad-dashboard.service" /etc/systemd/system/
cp "$SCRIPT_DIR/systemd/vps-gurad-agent.service" /etc/systemd/system/

# Thread the dashboard's own internalToken (single-agent-on-same-box case)
# straight from config.json into the agent's unit file automatically —
# this is the actual fix for "tokens don't match": nothing gets
# hand-copied between config.json and the unit file.
INTERNAL_TOKEN="$(node -e "console.log(JSON.parse(require('fs').readFileSync('$INSTALL_DIR/config.json')).internalToken)")"
sed -i "s|^#Environment=VPS_GURAD_AGENT_TOKEN=.*|Environment=VPS_GURAD_AGENT_TOKEN=${INTERNAL_TOKEN}|" /etc/systemd/system/vps-gurad-agent.service
sed -i "s|^#Environment=VPS_GURAD_AGENT_ID=.*|Environment=VPS_GURAD_AGENT_ID=vps-1|" /etc/systemd/system/vps-gurad-agent.service
sed -i "s|^Environment=VPS_GURAD_SERVER=.*|Environment=VPS_GURAD_SERVER=http://127.0.0.1:8787|" /etc/systemd/system/vps-gurad-agent.service

systemctl daemon-reload

if [ "$MODE" != "agent-only" ]; then
  log "Starting dashboard"
  systemctl enable --now vps-gurad-dashboard
fi
if [ "$MODE" != "dashboard-only" ]; then
  log "Starting agent"
  systemctl enable --now vps-gurad-agent
fi

sleep 1
echo ""
echo "=== Status ==="
[ "$MODE" != "agent-only" ] && systemctl --no-pager --lines=0 status vps-gurad-dashboard || true
[ "$MODE" != "dashboard-only" ] && systemctl --no-pager --lines=0 status vps-gurad-agent || true

echo ""
log "Done"
echo "Dashboard: http://127.0.0.1:8787 (use SSH tunnel or reverse proxy for remote access)"
echo "Logs:      sudo journalctl -u vps-gurad-agent -f"
echo "           sudo journalctl -u vps-gurad-dashboard -f"

if [ -f "$INSTALL_DIR/agents.json" ]; then
  echo ""
  echo "=== Additional VPS agents ==="
  echo "This dashboard was set up for multiple agents. For each additional"
  echo "VPS, copy this project there and run:"
  echo ""
  node -e "
const tokens = JSON.parse(require('fs').readFileSync('$INSTALL_DIR/agents.json'));
const entries = Object.entries(tokens).filter(([,label]) => label !== 'vps-1');
for (const [token, label] of entries) {
  console.log('  sudo ./install.sh --agent-only');
  console.log('    # when prompted:');
  console.log('    #   Dashboard URL:  http://THIS-DASHBOARD-HOST:8787  (use its real reachable address)');
  console.log('    #   Agent token:    ' + token);
  console.log('    #   Agent label:    ' + label);
  console.log('');
}
"
fi
