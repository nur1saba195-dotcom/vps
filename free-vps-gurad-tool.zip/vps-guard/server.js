import express from "express";
import session from "express-session";
import helmet from "helmet";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (!fs.existsSync(path.join(__dirname, "config.json"))) {
  console.error("Run `node setup.js` first.");
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8"));

// Optional: agents.json maps agentToken -> label, for running several VPS
// with distinct tokens instead of one shared internalToken. Falls back to
// the single shared token if the file doesn't exist, so existing single-VPS
// setups keep working unchanged.
let agentTokens = null; // Map<token, label> | null
const agentsFile = path.join(__dirname, "agents.json");
if (fs.existsSync(agentsFile)) {
  try {
    const raw = JSON.parse(fs.readFileSync(agentsFile, "utf8"));
    agentTokens = new Map(Object.entries(raw));
  } catch { agentTokens = null; }
}

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", false);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "24kb" }));
app.use(session({
  name: "vg.sid",
  secret: cfg.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const agents = new Map();
const attackers = new Map();
const events = [];
const started = Date.now();
const MAX_ATTACKERS = 5000;
const MAX_EVENTS = 150;

function requireLogin(req, res, next) {
  if (req.session.user === cfg.username) return next();
  res.status(401).json({ error: "login_required" });
}

function timingSafeStrEqual(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

function requireAgent(req, res, next) {
  const supplied = String(req.get("x-vps-gurad-agent") || "");
  if (agentTokens) {
    for (const token of agentTokens.keys()) {
      if (timingSafeStrEqual(supplied, token)) return next();
    }
    return res.status(401).json({ error: "unauthorized" });
  }
  if (!timingSafeStrEqual(supplied, cfg.internalToken)) return res.status(401).json({ error: "unauthorized" });
  next();
}

function passwordOK(password) {
  const candidate = crypto.scryptSync(password, cfg.salt, 64);
  const stored = Buffer.from(cfg.passwordHash, "hex");
  return candidate.length === stored.length && crypto.timingSafeEqual(candidate, stored);
}

app.get("/api/me", (req, res) => res.json({ loggedIn: req.session.user === cfg.username, username: cfg.username }));

app.post("/api/login", (req, res) => {
  const username = String(req.body?.username || "").trim();
  // Strip only newline/carriage-return characters — an extremely common
  // copy-paste artifact (e.g. pasting from a text file, terminal, or a
  // password manager that appends a trailing newline) that silently
  // breaks login with zero visible sign anything is wrong. Other
  // whitespace is left untouched in case it's genuinely part of the
  // password the user chose.
  const password = String(req.body?.password || "").replace(/[\r\n]+$/, "");
  if (username.length > 80 || password.length > 300 || username !== cfg.username || !passwordOK(password))
    return res.status(401).json({ error: "Invalid username or password" });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "session_error" });
    req.session.user = cfg.username;
    res.json({ ok: true });
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/status", requireLogin, (_req, res) => {
  res.json({
    uptime: Math.floor((Date.now() - started) / 1000),
    agents: [...agents.values()].sort((a, b) => b.lastSeen - a.lastSeen),
    attackers: [...attackers.values()].sort((a, b) => b.score - a.score).slice(0, 500),
    events: events.slice(0, MAX_EVENTS)
  });
});

const VALID_REASONS = new Set([
  "connection_flood", "connection_flood_watch", "syn_flood", "port_scan",
  "auth_brute_force", "udp_flood_signal", "http_flood", "observe"
]);

app.post("/api/report", requireAgent, (req, res) => {
  const b = req.body || {};
  if (typeof b.agentId !== "string" || b.agentId.length > 120) return res.status(400).json({ error: "bad agent" });
  const now = Date.now();
  const isNewAgent = !agents.has(b.agentId);
  agents.set(b.agentId, {
    agentId: b.agentId, hostname: String(b.hostname || "unknown").slice(0, 120),
    os: String(b.os || "unknown").slice(0, 100), connections: Number(b.connections || 0),
    blocked: Number(b.blocked || 0), cpu: Number(b.cpu || 0), memory: Number(b.memory || 0), lastSeen: now
  });
  if (isNewAgent) {
    events.unshift({ ts: now, agentId: b.agentId, message: `Agent connected: ${String(b.hostname || b.agentId).slice(0, 100)}` });
  }
  for (const x of Array.isArray(b.attackers) ? b.attackers.slice(0, 100) : []) {
    const ip = String(x.ip || "");
    if (!/^[0-9a-fA-F:.]{3,80}$/.test(ip)) continue;
    const reason = String(x.reason || "observe");
    attackers.set(`${b.agentId}:${ip}`, {
      ip, score: Number(x.score || 0), connections: Number(x.connections || 0),
      action: String(x.action || "observe"),
      reason: VALID_REASONS.has(reason) ? reason : "observe",
      lastSeen: now, agentId: b.agentId
    });
  }
  while (attackers.size > MAX_ATTACKERS) attackers.delete(attackers.keys().next().value);
  events.unshift({ ts: now, agentId: b.agentId, message: String(b.message || "agent report").slice(0, 180) });
  events.length = Math.min(events.length, MAX_EVENTS);
  res.json({ ok: true });
});

// Passive cleanup: agents that stop reporting drop off the dashboard after
// 2 minutes of silence rather than lingering forever as stale "protected".
setInterval(() => {
  const cutoff = Date.now() - 120000;
  for (const [id, a] of agents) if (a.lastSeen < cutoff) agents.delete(id);
}, 30000).unref();

app.get("/healthz", (_req, res) => res.json({ ok: true }));

app.listen(cfg.port, cfg.host, () => console.log(`VPS Gurad running on http://${cfg.host}:${cfg.port}`));
