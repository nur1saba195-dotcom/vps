#!/usr/bin/env bash
# kernel-hardening.sh — kernel-level (iptables) DDoS rate-limiting for VPS Gurad.
#
# WHAT THIS DOES
#   Adds a small, dedicated iptables chain (VPS_GURAD_RATE) that rate-limits
#   new SYN packets per source IP *before* they reach the application layer.
#   This is a second, faster line of defense underneath agent.js: the kernel
#   drops excess packets in microseconds, versus agent.js's 5-second polling
#   interval. Neither replaces the other — the kernel rule catches the first
#   instant of a flood; agent.js catches sustained/slow-building patterns
#   (port scans, brute force, low-and-slow floods) that a flat packet-rate
#   limit can't see.
#
# SAFETY
#   - SSH (port 22) gets its OWN, more generous limit, kept separate from the
#     general web/all-ports limit. An attacker flooding port 80 will not push
#     you over your own SSH rate limit and lock you out of the box.
#   - Defaults are deliberately generous (see THRESHOLDS below) — they're
#     sized to only catch genuine floods, not a page going viral or a dozen
#     people behind the same office NAT. Tune with the flags below if needed.
#   - Fully idempotent: safe to re-run any number of times.
#   - Fully reversible: `./kernel-hardening.sh --remove` deletes every rule
#     this script adds and nothing else. It never touches unrelated chains.
#   - This script only ever appends rules to a dedicated custom chain that it
#     owns. It does not modify your existing INPUT policy or any other rules
#     you may already have.
#
# WHAT THIS DOES NOT DO
#   It cannot stop a volumetric flood before it reaches your VPS's network
#   interface — that requires upstream/provider-level DDoS mitigation, which
#   no host-level tool (this one included) can substitute for. This script
#   only limits what gets past the interface and into your TCP stack.
#
# USAGE
#   sudo ./kernel-hardening.sh                 install with defaults
#   sudo ./kernel-hardening.sh --ssh-port 2222  if you moved SSH off port 22
#   sudo ./kernel-hardening.sh --syn-rate 300   raise the general SYN limit
#   sudo ./kernel-hardening.sh --remove         fully uninstall
#   sudo ./kernel-hardening.sh --status         show current rule hit counts

set -euo pipefail

CHAIN="VPS_GURAD_RATE"
SSH_PORT=22
SYN_RATE="200/sec"     # general per-source-IP SYN rate before dropping
SYN_BURST=100
SSH_RATE="10/min"      # separate, much stricter limit — SSH sees far less legitimate traffic than a web port
SSH_BURST=15
UDP_RATE="100/sec"
UDP_BURST=50
ACTION="install"

while [ $# -gt 0 ]; do
  case "$1" in
    --remove) ACTION="remove"; shift ;;
    --status) ACTION="status"; shift ;;
    --ssh-port) SSH_PORT="$2"; shift 2 ;;
    --syn-rate) SYN_RATE="$2/sec"; shift 2 ;;
    --ssh-rate) SSH_RATE="$2/min"; shift 2 ;;
    --udp-rate) UDP_RATE="$2/sec"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--remove|--status] [--ssh-port N] [--syn-rate N] [--ssh-rate N] [--udp-rate N]"
      exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "This needs root (it edits the firewall). Run with sudo." >&2
  exit 1
fi

if ! command -v iptables >/dev/null 2>&1; then
  echo "iptables not found. This script targets Linux hosts with iptables installed." >&2
  echo "(On Windows, use the agent's built-in Windows Firewall blocking instead — no extra step needed.)" >&2
  exit 1
fi

remove_rules() {
  echo "Removing VPS Gurad kernel rate-limit rules..."
  iptables -D INPUT -j "$CHAIN" 2>/dev/null || true
  iptables -F "$CHAIN" 2>/dev/null || true
  iptables -X "$CHAIN" 2>/dev/null || true
  echo "Done. Your other iptables rules (including the separate VPS_GURAD block-list chain used by agent.js) are untouched."
}

show_status() {
  if ! iptables -L "$CHAIN" -n -v >/dev/null 2>&1; then
    echo "Not installed. Run without --status/--remove to install."
    exit 0
  fi
  echo "=== $CHAIN rules and hit counts ==="
  iptables -L "$CHAIN" -n -v
}

install_rules() {
  echo "Installing kernel-level rate limiting (chain: $CHAIN)..."

  # SYN cookies: lets the kernel survive a SYN-queue-exhaustion flood even
  # if every rate limit below is bypassed by spoofed source IPs (against
  # which per-source-IP limiting is powerless by definition).
  if [ -w /proc/sys/net/ipv4/tcp_syncookies ]; then
    echo 1 > /proc/sys/net/ipv4/tcp_syncookies
  fi
  if ! grep -q "^net.ipv4.tcp_syncookies" /etc/sysctl.conf 2>/dev/null; then
    echo "net.ipv4.tcp_syncookies = 1" >> /etc/sysctl.conf
  fi

  # Create the chain if it doesn't already exist (idempotent).
  iptables -N "$CHAIN" 2>/dev/null || true
  iptables -F "$CHAIN"

  # Always allow already-established/related traffic through immediately —
  # this is the fast path and must come first, or every packet of every
  # existing legitimate connection would be re-evaluated against the rate
  # limits below on every single packet.
  iptables -A "$CHAIN" -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

  # SSH gets its own generous-but-tight limit, kept structurally separate
  # from the general rule below so a flood against any other port can never
  # consume the SSH allowance and lock the owner out.
  iptables -A "$CHAIN" -p tcp --syn --dport "$SSH_PORT" \
    -m hashlimit --hashlimit-name vg_ssh --hashlimit-mode srcip \
    --hashlimit-upto "$SSH_RATE" --hashlimit-burst "$SSH_BURST" -j ACCEPT
  iptables -A "$CHAIN" -p tcp --syn --dport "$SSH_PORT" -j DROP

  # General per-source-IP SYN rate limit for all other TCP ports.
  iptables -A "$CHAIN" -p tcp --syn \
    -m hashlimit --hashlimit-name vg_syn --hashlimit-mode srcip \
    --hashlimit-upto "$SYN_RATE" --hashlimit-burst "$SYN_BURST" -j ACCEPT
  iptables -A "$CHAIN" -p tcp --syn -j DROP

  # UDP is connectionless, so this limits packets-per-second per source
  # rather than "new connections" — the closest kernel-level equivalent.
  iptables -A "$CHAIN" -p udp \
    -m hashlimit --hashlimit-name vg_udp --hashlimit-mode srcip \
    --hashlimit-upto "$UDP_RATE" --hashlimit-burst "$UDP_BURST" -j ACCEPT
  iptables -A "$CHAIN" -p udp -j DROP

  # Drop packets with impossible flag combinations. These never occur in
  # real TCP traffic and are common output from low-quality flood tools;
  # dropping them here costs the kernel far less than letting them reach
  # conntrack/the app.
  iptables -A "$CHAIN" -p tcp --tcp-flags ALL ALL -j DROP
  iptables -A "$CHAIN" -p tcp --tcp-flags ALL NONE -j DROP
  iptables -A "$CHAIN" -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
  iptables -A "$CHAIN" -p tcp --tcp-flags SYN,RST SYN,RST -j DROP

  # Everything else (non-SYN TCP that isn't established/related — a rare
  # edge case — and all other protocols) passes through unaffected.
  iptables -A "$CHAIN" -j RETURN

  # Hook the chain into INPUT, but only once, and ahead of the VPS_GURAD
  # per-IP block-list chain that agent.js manages, so a rate-limited packet
  # never even reaches the (larger, slower-to-scan) block-list.
  if ! iptables -C INPUT -j "$CHAIN" 2>/dev/null; then
    iptables -I INPUT 1 -j "$CHAIN"
  fi

  echo "Installed. SSH (port $SSH_PORT) limited to $SSH_RATE per source IP (burst $SSH_BURST)."
  echo "All other TCP limited to $SYN_RATE new connections per source IP (burst $SYN_BURST)."
  echo "UDP limited to $UDP_RATE per source IP (burst $UDP_BURST)."
  echo ""
  echo "Check it's working:   sudo $0 --status"
  echo "Fully remove it:      sudo $0 --remove"
  echo ""
  echo "NOTE: these rules use iptables' in-memory ruleset, which does NOT"
  echo "survive a reboot by default. Persist them with 'iptables-persistent'"
  echo "(Debian/Ubuntu: sudo apt install iptables-persistent) or run this"
  echo "script again from the systemd service's ExecStartPre (see the"
  echo "generated vps-gurad-agent.service if you used the systemd installer)."
}

case "$ACTION" in
  install) install_rules ;;
  remove) remove_rules ;;
  status) show_status ;;
esac
