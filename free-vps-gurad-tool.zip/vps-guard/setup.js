import fs from "node:fs/promises";
import crypto from "node:crypto";
import readline from "node:readline";
import { stdin as input, stdout as output } from "node:process";

// Queue-based prompter: buffers each answered line via the 'line' event
// instead of calling rl.question() repeatedly. This avoids a stdin race
// (present in Node's readline/promises rl.question() on piped, non-TTY
// input) where the interface can miss the moment between one question
// resolving and the next one being armed, silently truncating the prompt
// sequence. Interactive typing at a real terminal was never affected —
// this only matters for scripted/CI/`expect`-driven runs — but it should
// work reliably either way.
function createPrompter() {
  const rl = readline.createInterface({ input, output, terminal: false });
  const queue = [];
  const waiters = [];
  let closed = false;
  rl.on("line", (line) => {
    if (waiters.length) waiters.shift()(line);
    else queue.push(line);
  });
  rl.on("close", () => { closed = true; while (waiters.length) waiters.shift()(null); });
  return {
    ask(promptText) {
      output.write(promptText);
      return new Promise(resolve => {
        if (queue.length) return resolve(queue.shift());
        if (closed) return resolve(null);
        waiters.push(resolve);
      });
    },
    close() { rl.close(); }
  };
}

async function main() {
  const p = createPrompter();
  let username, password, multiAns;
  try {
    username = ((await p.ask("Admin username [admin]: ")) || "").trim() || "admin";
    password = (await p.ask("Admin password: ")) || "";
    multiAns = ((await p.ask("How many VPS agents will report to this dashboard? [1]: ")) || "").trim();
  } finally {
    p.close();
  }

  if (password.length < 10) {
    console.error("Password must be at least 10 characters.");
    process.exitCode = 1;
    return;
  }

  const agentCount = Math.max(1, Math.min(200, parseInt(multiAns || "1", 10) || 1));

  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  const internalToken = crypto.randomBytes(32).toString("hex");

  await fs.writeFile("config.json", JSON.stringify({
    username,
    passwordHash: hash,
    salt,
    internalToken,
    sessionSecret: crypto.randomBytes(48).toString("hex"),
    port: 8787,
    host: "127.0.0.1",
    blockSeconds: 900,
    connectionThreshold: 120,
    synThreshold: 40,
    portScanThreshold: 15,
    authFailThreshold: 6,
    udpThreshold: 200,
    httpFloodThreshold: 300,
    scoreThreshold: 60
  }, null, 2), { mode: 0o600 });

  console.log("\nSetup complete. Start the dashboard with: npm start");
  console.log("Then open: http://127.0.0.1:8787");
  console.log("Keep config.json private.");

  if (agentCount > 1) {
    const tokens = {};
    for (let i = 1; i <= agentCount; i++) {
      tokens[crypto.randomBytes(32).toString("hex")] = `vps-${i}`;
    }
    await fs.writeFile("agents.json", JSON.stringify(tokens, null, 2), { mode: 0o600 });
    console.log(`\nGenerated ${agentCount} per-agent tokens in agents.json (mode 600).`);
    console.log("On each VPS, run the agent with its own token and label, e.g.:");
    console.log("  VPS_GURAD_SERVER=https://your-dashboard-host \\");
    console.log("  VPS_GURAD_AGENT_TOKEN=<one token from agents.json> \\");
    console.log("  VPS_GURAD_AGENT_ID=<matching label, e.g. vps-1> \\");
    console.log("  sudo node agent.js");
    console.log("\nCopy agent.js + config.json's host/port info to each VPS; only the");
    console.log("dashboard box needs server.js and agents.json.");
  } else {
    console.log("\nSingle-agent mode: agent.js will use config.json's internalToken automatically.");
    console.log("Run on the VPS with: sudo node agent.js");
  }

  console.log("\n— Recommended next steps for production / 24-7 use —");
  console.log("1. Kernel-level rate limiting (Linux only, second layer under agent.js):");
  console.log("     sudo ./kernel-hardening.sh");
  console.log("2. Run continuously with systemd instead of a manual `node agent.js`:");
  console.log("     see systemd/README.md for the two-command install.");
  console.log("Both steps are optional but strongly recommended — without them the");
  console.log("agent still works, but won't survive a reboot and skips the faster");
  console.log("kernel-level SYN/UDP rate limiting.");
}

await main();
